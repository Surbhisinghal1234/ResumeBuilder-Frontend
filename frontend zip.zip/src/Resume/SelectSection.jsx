import React from 'react'
import { Outlet } from 'react-router-dom'

function SelectSection() {
  return (
    <div className='flex items-center justify-center font-medium mt-5 text-2xl'>
         Select a section to edit
    </div>
  )
}

export default SelectSection